
📝 INSTRUÇÕES PARA USAR EM PRODUÇÃO

1. Suba os arquivos para seu repositório GitHub (ou plataforma como Railway, Render etc)
2. Para o backend (server.js):
   - Ambiente Node.js
   - Comando para instalar dependências: npm install
   - Comando para iniciar: node server.js

3. Para o index.html:
   - Pode ser hospedado na Hostinger ou em serviços como Netlify, Vercel, GitHub Pages.

4. O index.html já está apontando para:
   https://rastreamento-amandita.onrender.com/pedidos-shopify

5. Altere o número do QR code e a API Z-API se quiser personalizar.

Suporte via ChatGPT.
